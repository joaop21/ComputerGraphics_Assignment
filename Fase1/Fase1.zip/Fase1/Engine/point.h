#ifndef POINT_H
#define POINT_H
#endif

using namespace std;
/**
* @brief classe que define intancias de Ponto
*/
class Point{
    public:
        float x,y,z;
};
